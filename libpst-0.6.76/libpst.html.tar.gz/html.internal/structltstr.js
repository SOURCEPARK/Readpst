var structltstr =
[
    [ "operator()", "structltstr.html#a8d497502350a22b670e7011152b98ffd", null ]
];