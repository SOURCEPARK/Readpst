var structpst__table__ptr__struct32 =
[
    [ "offset", "structpst__table__ptr__struct32.html#acc085c5c1b3d1a3c9d8869470141524e", null ],
    [ "start", "structpst__table__ptr__struct32.html#a3651cee33cf038ce2dbe53dc40c0a18c", null ],
    [ "u1", "structpst__table__ptr__struct32.html#aa800577de6c228cd3b532c26f96c0619", null ]
];