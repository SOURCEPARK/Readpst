var structpst__block__recorder =
[
    [ "next", "structpst__block__recorder.html#afda3df84a5c01d61345282ccfd91450d", null ],
    [ "offset", "structpst__block__recorder.html#a9c0cf29deb0b9622129acba7065e59db", null ],
    [ "readcount", "structpst__block__recorder.html#a8f753d18bd55c2f573a5c28e0cc7beca", null ],
    [ "size", "structpst__block__recorder.html#a489f1b1fc27de9d306b53cee6d27ceae", null ]
];