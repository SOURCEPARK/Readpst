var dir_68267d1309a1af8e8297ef4c3efbcdba =
[
    [ "common.h", "common_8h.html", [
      [ "FILETIME", "structFILETIME.html", "structFILETIME" ]
    ] ],
    [ "debug.c", "debug_8c.html", "debug_8c" ],
    [ "define.h", "define_8h.html", "define_8h" ],
    [ "deltasearch.cpp", "deltasearch_8cpp.html", "deltasearch_8cpp" ],
    [ "dumpblocks.c", "dumpblocks_8c.html", "dumpblocks_8c" ],
    [ "getidblock.c", "getidblock_8c.html", "getidblock_8c" ],
    [ "libpst.c", "libpst_8c.html", "libpst_8c" ],
    [ "libpst.h", "libpst_8h.html", "libpst_8h" ],
    [ "libstrfunc.c", "libstrfunc_8c.html", "libstrfunc_8c" ],
    [ "libstrfunc.h", "libstrfunc_8h.html", "libstrfunc_8h" ],
    [ "lspst.c", "lspst_8c.html", "lspst_8c" ],
    [ "lzfu.c", "lzfu_8c.html", "lzfu_8c" ],
    [ "lzfu.h", "lzfu_8h.html", "lzfu_8h" ],
    [ "msg.cpp", "msg_8cpp.html", "msg_8cpp" ],
    [ "msg.h", "msg_8h.html", "msg_8h" ],
    [ "nick2ldif.cpp", "nick2ldif_8cpp.html", "nick2ldif_8cpp" ],
    [ "pst2dii.cpp", "pst2dii_8cpp.html", "pst2dii_8cpp" ],
    [ "pst2ldif.cpp", "pst2ldif_8cpp.html", "pst2ldif_8cpp" ],
    [ "readpst.c", "readpst_8c.html", "readpst_8c" ],
    [ "timeconv.c", "timeconv_8c.html", "timeconv_8c" ],
    [ "timeconv.h", "timeconv_8h.html", "timeconv_8h" ],
    [ "vbuf.c", "vbuf_8c.html", "vbuf_8c" ],
    [ "vbuf.h", "vbuf_8h.html", "vbuf_8h" ],
    [ "XGetopt.c", "XGetopt_8c.html", "XGetopt_8c" ],
    [ "XGetopt.h", "XGetopt_8h.html", "XGetopt_8h" ]
];