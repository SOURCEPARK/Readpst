var structpst__debug__func =
[
    [ "name", "structpst__debug__func.html#a511d2666cfc718943583ddc8802aa6a0", null ],
    [ "next", "structpst__debug__func.html#adab0646e99d4ba3cd3c51ed52cf93f70", null ]
];