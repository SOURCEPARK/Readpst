var structpst__index64 =
[
    [ "id", "structpst__index64.html#a0ed4d33b852a847e8a6c72f41136de94", null ],
    [ "offset", "structpst__index64.html#a8ec7ae7c4515ea527431a03daa09caef", null ],
    [ "size", "structpst__index64.html#a5d20df8004ef348c4403809daf1bad2f", null ],
    [ "u0", "structpst__index64.html#ab491c2d60c50fe468c3b1b9cce4213bc", null ],
    [ "u1", "structpst__index64.html#a3c05b18bf53ffa88a2ef79d4d8cbaf72", null ]
];