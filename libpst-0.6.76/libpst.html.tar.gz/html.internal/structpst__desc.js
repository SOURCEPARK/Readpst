var structpst__desc =
[
    [ "d_id", "structpst__desc.html#a3e32c5faa19894ab51a787bd5e9e0d93", null ],
    [ "desc_id", "structpst__desc.html#a0bc9af11e3f2ba1ae5c48e3924d93aa4", null ],
    [ "parent_d_id", "structpst__desc.html#afcce984157aad249c1b855135c277994", null ],
    [ "tree_id", "structpst__desc.html#aa98c88b1295bd3102a11c1b87ca473cb", null ],
    [ "u1", "structpst__desc.html#aadc7d397db497286bcb8397245d2d8c2", null ]
];