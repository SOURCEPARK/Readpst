var structpst__subblocks =
[
    [ "subblock_count", "structpst__subblocks.html#a2b436cca47ef96a1adcfc5a50cc1aa49", null ],
    [ "subs", "structpst__subblocks.html#ac1ab4f3276ee458f8582fce242e64499", null ]
];