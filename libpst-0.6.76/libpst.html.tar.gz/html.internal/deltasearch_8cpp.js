var deltasearch_8cpp =
[
    [ "main", "deltasearch_8cpp.html#ad1835a0a190dc5fe4f925bb69443c770", null ],
    [ "comp_enc", "deltasearch_8cpp.html#aa6147c931febc8cbf599f2bbecdaf42f", null ]
];