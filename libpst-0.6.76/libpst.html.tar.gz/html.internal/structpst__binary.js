var structpst__binary =
[
    [ "data", "structpst__binary.html#a2d172aa42caca6a4e58510e3eddd9ea8", null ],
    [ "size", "structpst__binary.html#a3aea360370d0414a1a25fa878a14e8dc", null ]
];