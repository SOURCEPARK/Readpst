var structpst__holder =
[
    [ "base64", "structpst__holder.html#a7e5a0f33ae1c3c1f85ffcd4ed41789d7", null ],
    [ "base64_extra", "structpst__holder.html#a2c94b9060a27812d0ce16477b2325742", null ],
    [ "base64_extra_chars", "structpst__holder.html#a88084737baf3d1ceb544bdfb31dccc64", null ],
    [ "base64_line_count", "structpst__holder.html#aefa9176dafad7e07b827b5af76e04fec", null ],
    [ "buf", "structpst__holder.html#aedafcd66bfc608c771217af2a7f37b40", null ],
    [ "fp", "structpst__holder.html#aeb6105dfe5b1c181a48f308be51fc885", null ]
];