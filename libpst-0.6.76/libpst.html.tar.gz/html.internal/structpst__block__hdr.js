var structpst__block__hdr =
[
    [ "index_offset", "structpst__block__hdr.html#a38c84e889b426e45082e3b2925c41985", null ],
    [ "offset", "structpst__block__hdr.html#a7d4d011822f52e041bbfeefde0c025c2", null ],
    [ "type", "structpst__block__hdr.html#a33cd295afd2a636c00b21f0cabff5ac3", null ]
];