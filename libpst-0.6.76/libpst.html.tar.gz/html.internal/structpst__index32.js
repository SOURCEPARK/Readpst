var structpst__index32 =
[
    [ "id", "structpst__index32.html#a51d350882c0e7ced02157713a65c26e9", null ],
    [ "offset", "structpst__index32.html#a3bf2b88b5da113bb6e8aaf16a538c724", null ],
    [ "size", "structpst__index32.html#a1f8df930d2d98cfd78a45e303bba8276", null ],
    [ "u1", "structpst__index32.html#a13d7ad80d80b9dcaa168d8f638b17b90", null ]
];