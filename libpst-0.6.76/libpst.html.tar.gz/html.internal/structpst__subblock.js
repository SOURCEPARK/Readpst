var structpst__subblock =
[
    [ "buf", "structpst__subblock.html#aa2c04a37142a56f3ffe47251f54a04bd", null ],
    [ "i_offset", "structpst__subblock.html#a925d5da6194edc62d2d39b58e8e938dd", null ],
    [ "read_size", "structpst__subblock.html#a52fdb971eec38a432bb1412653f4edaa", null ]
];