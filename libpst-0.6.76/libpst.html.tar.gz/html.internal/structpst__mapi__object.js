var structpst__mapi__object =
[
    [ "count_elements", "structpst__mapi__object.html#afb809567b68435a4895b87ecf22ee3ff", null ],
    [ "count_objects", "structpst__mapi__object.html#afe5fa808931ef1221f2d5d364a1a57f8", null ],
    [ "elements", "structpst__mapi__object.html#a35a9c8a903ba9b20389c66ef9d402cf8", null ],
    [ "next", "structpst__mapi__object.html#a74ab27bb75b980deacefe10fba8a1ae8", null ],
    [ "orig_count", "structpst__mapi__object.html#aaebc8a404af70cb9fb06a24a547a0f8c", null ]
];