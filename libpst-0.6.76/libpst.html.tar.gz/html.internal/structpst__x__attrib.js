var structpst__x__attrib =
[
    [ "extended", "structpst__x__attrib.html#aca6383fec623181425fd9ab4fe1b980c", null ],
    [ "map", "structpst__x__attrib.html#ab3d7c289a478bd6b034d879076dce030", null ],
    [ "type", "structpst__x__attrib.html#af270d0c40c01128dc7aa1618a382f9f1", null ]
];