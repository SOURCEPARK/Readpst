var structpst__block__header =
[
    [ "count", "structpst__block__header.html#a668be669b4ad705920db13b3ec20e6ff", null ],
    [ "type", "structpst__block__header.html#a9c19558d765d1474fae14d8ea945d9c5", null ]
];