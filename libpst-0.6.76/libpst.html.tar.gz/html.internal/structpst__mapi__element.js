var structpst__mapi__element =
[
    [ "data", "structpst__mapi__element.html#a20cc11377faa593b2604e97b066680bb", null ],
    [ "extra", "structpst__mapi__element.html#ad128e3e6d8274eed99e1340ee49984b7", null ],
    [ "mapi_id", "structpst__mapi__element.html#aeed7bb11cedcb6c5d364d1a9533e0cdb", null ],
    [ "size", "structpst__mapi__element.html#af7305860294e05741c4993eb7248edd5", null ],
    [ "type", "structpst__mapi__element.html#a7f80c868d8b9d17d800b2c82b7874f4b", null ]
];