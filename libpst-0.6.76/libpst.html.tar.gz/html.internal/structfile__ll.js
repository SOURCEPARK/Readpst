var structfile__ll =
[
    [ "file_ll", "structfile__ll.html#a0bdb33bbc7c8f720aeb38ea6c09c6c3a", null ],
    [ "dname", "structfile__ll.html#a9fb86fe8e5c9134c732f209c3a2b253f", null ],
    [ "email_count", "structfile__ll.html#af591f36b22d249f33ea6f098702d1bfe", null ],
    [ "item_count", "structfile__ll.html#ab2f9f7861aceb7ca4759f71d713d3451", null ],
    [ "name", "structfile__ll.html#a87da7eebcf4460b25897af1a02a89579", null ],
    [ "name", "structfile__ll.html#abc23b3ca58927773d28e0a328a025536", null ],
    [ "output", "structfile__ll.html#a2a0f1a12fa24f0009369fa988d2ba0af", null ],
    [ "skip_count", "structfile__ll.html#a7e19fcbb721213a99445e631d3f7a174", null ],
    [ "stored_count", "structfile__ll.html#a7443a2c43d88db5de4a0fd7c29739aa3", null ],
    [ "type", "structfile__ll.html#a959a6a05181e42587afd3ac710af2fd6", null ]
];