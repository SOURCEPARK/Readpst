var structpst__desc32 =
[
    [ "d_id", "structpst__desc32.html#aa908301f9a9933bd3ceb49c6c343db97", null ],
    [ "desc_id", "structpst__desc32.html#a49e85d97e79c2e1ee9a52481b5c7446b", null ],
    [ "parent_d_id", "structpst__desc32.html#af53ecb79b95a97e6e6e9cd1675c87296", null ],
    [ "tree_id", "structpst__desc32.html#a3dc9c6bd3e620a12397c90fc9e2e4b24", null ]
];