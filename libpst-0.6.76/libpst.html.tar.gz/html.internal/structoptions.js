var structoptions =
[
    [ "date_format", "structoptions.html#ac5d23c53b79e96703566fcd87794af1d", null ],
    [ "long_format", "structoptions.html#a74209a63fd3447413971da83ddddb820", null ]
];