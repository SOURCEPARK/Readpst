var struct__lzfuheader =
[
    [ "cbRawSize", "struct__lzfuheader.html#a5f7ad6ff4a344d3675990d52cf0c629d", null ],
    [ "cbSize", "struct__lzfuheader.html#a9b4c533584e33ebf44251685ecf6c7d8", null ],
    [ "dwCRC", "struct__lzfuheader.html#a62598f32fa068b1615ad243abefc1093", null ],
    [ "dwMagic", "struct__lzfuheader.html#a24babc70a78ff10422e3b3fc4797c060", null ]
];