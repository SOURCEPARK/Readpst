var XGetopt_8c =
[
    [ "getopt", "XGetopt_8c.html#a077dc731b881f74c845bc6f2e0509b95", null ],
    [ "optarg", "XGetopt_8c.html#adb50a0eab9fed92fc3bfc7dfa4f2c410", null ],
    [ "optind", "XGetopt_8c.html#ad5e1c16213bbee2d5e8cc363309f418c", null ]
];