var structpst__item__extra__field =
[
    [ "field_name", "structpst__item__extra__field.html#a67646f3185b7916b84b4fe81b4617d0e", null ],
    [ "next", "structpst__item__extra__field.html#abbd93ac0cb48dfbc9710cdffaed0e8e2", null ],
    [ "value", "structpst__item__extra__field.html#a9ef6d10f0a61d28b9d56121935dc1230", null ]
];