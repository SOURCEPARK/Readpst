var XGetopt_8h =
[
    [ "getopt", "XGetopt_8h.html#a077dc731b881f74c845bc6f2e0509b95", null ],
    [ "optarg", "XGetopt_8h.html#adb50a0eab9fed92fc3bfc7dfa4f2c410", null ],
    [ "opterr", "XGetopt_8h.html#ae30f05ee1e2e5652f174a35c7875d25e", null ],
    [ "optind", "XGetopt_8h.html#ad5e1c16213bbee2d5e8cc363309f418c", null ]
];