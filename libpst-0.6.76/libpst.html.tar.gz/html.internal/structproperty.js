var structproperty =
[
    [ "flags", "structproperty.html#a8046a6aa483c6b4d43c23669a2778cf2", null ],
    [ "length", "structproperty.html#aeb5d0393a3aa49f3c922941ec6a23777", null ],
    [ "reserved", "structproperty.html#a75943342e109cb66e8e6de3357d50c6e", null ],
    [ "tag", "structproperty.html#a3dbf6b7cdb0f5626313bd49ba1b9f8f2", null ]
];